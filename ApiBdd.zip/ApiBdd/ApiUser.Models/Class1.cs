﻿namespace ApiUser.Models
{
    public class Class1
    {

    }
}