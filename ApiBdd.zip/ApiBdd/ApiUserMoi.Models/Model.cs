﻿namespace ApiUserMoi
{
    abstract public class Model
    {
        public int Id { get; set; }
    }
}
