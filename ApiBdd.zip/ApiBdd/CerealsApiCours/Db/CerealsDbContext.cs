﻿using Microsoft.EntityFrameworkCore;

namespace CerealsApiCours.Db
{
    public class CerealsDbContext : DbContext
    {
        protected override OnC
    }
}
