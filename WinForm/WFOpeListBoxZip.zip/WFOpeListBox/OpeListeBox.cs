﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;

namespace WFOpeListBox
{
    public partial class OpeListeBox : Form
    {
        //List<string> nameList = new List<string> { };
        public OpeListeBox()
        {
            InitializeComponent();
        }

        private void textBoxNewElement_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonAddLst_Click(object sender, EventArgs e)
        {
            listBox.Items.Add(textBoxNewElement.Text);          
        }

        private void listBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            string v = (string)listBox.SelectedItem;

            //if ()
            //{

            //}
     
        }

        private void textBoxIndexElement_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonSelect_Click(object sender, EventArgs e)
        {

        }

        private void buttonClearLst_Click(object sender, EventArgs e)
        {

        }

        private void textBoxItemsCount_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxSelectedIndex_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxText_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
