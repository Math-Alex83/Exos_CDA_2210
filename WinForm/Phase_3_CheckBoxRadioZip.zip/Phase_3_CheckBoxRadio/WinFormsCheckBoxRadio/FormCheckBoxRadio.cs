﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsCheckBoxRadio
{
    public partial class FormCheckBoxRadio : Form
    {
        public FormCheckBoxRadio()
        {
            InitializeComponent();
        }

        private void labelindication_Click(object sender, EventArgs e)
        {

        }

        private void textBoxSaisieUtil_TextChanged(object sender, EventArgs e)
        {
            // copi le texte dans le label2 labelSaisieUtil
            labelSaisieUtil.Text = textBoxSaisieUtil.Text;

            // active le grpBox si du texte est saisie dans la textBox
            if (textBoxSaisieUtil.Text != "")
            {
                groupBoxChoix.Enabled = true;
            }
        }

        private void labelSaisieUtil_Click(object sender, EventArgs e)
        {
        }

        private void groupBoxChoix_Enter(object sender, EventArgs e)
        {

        }

        private void checkBoxCouleurFond_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxCouleurFond.Checked)
            {
                groupBoxFond.Visible = true;
            }
            else
            {
                groupBoxFond.Visible = false;
            }

        }

        private void checkBoxCouleurCaracteres_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBoxCasse_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void groupBoxFond_Enter(object sender, EventArgs e)
        {

        }

        private void radioButtonFondRouge_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButtonFondVert_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButtonFondBleu_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void groupBoxCarac_Enter(object sender, EventArgs e)
        {

        }

        private void radioButtonCaracRouge_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButtonCaracBlanc_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButtonCaracNoir_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void groupBoxCasse_Enter(object sender, EventArgs e)
        {

        }

        private void radioButtonCasseMinus_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButtonCasseMaj_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
